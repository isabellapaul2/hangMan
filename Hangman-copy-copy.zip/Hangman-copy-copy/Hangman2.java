import java.util.Scanner;
/**
 * Write a description of class Hangman2 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Hangman2
{

    public static void main()
    {
        Scanner in = new Scanner(System.in);
        String phrase = in.nextLine();
        phrase = phrase.toLowerCase();
        System.out.println("Enter a phrase: ");
        String under = "";
        int count = 0;
        for(int i = 0; i< phrase.length(); i++)
        {
            if (phrase.charAt(i) == ' ')
            {
                under += " "; 
            }
            else
                under += "_";
        }
        System.out.println('\u000C');
        char[] answer = under.toCharArray();
        System.out.println(answer);

        while(underscoreCheck(answer) && count < 7)
        {

            System.out.println("   enter a character: ");
            String guess1 = in.next().toLowerCase();
            char guess = guess1.charAt(0);
            boolean right = false;

            for(int i = 0; i< phrase.length(); i++)
            {
                if (phrase.charAt(i) == guess)
                {
                    answer[i] = guess;
                    right = true;
                }
            }
            if( right == false)
            {
                System.out.println("Wrong answer dummy!");
                count ++;
                if(count == 0)
                {
                    System.out.println("  ------  ");
                    System.out.println("  |       ");
                    System.out.println("  |       ");
                    System.out.println("  |       ");
                    System.out.println("_____     ");

                }
                else if(count == 1)
                {
                    System.out.println("  ------  ");
                    System.out.println("  |    0  ");
                    System.out.println("  |       ");
                    System.out.println("  |       ");
                    System.out.println("_____     ");

                }
                else if(count == 2)
                {
                    System.out.println("  ------  ");
                    System.out.println("  |    0  ");
                    System.out.println("  |    |  ");
                    System.out.println("  |       ");
                    System.out.println("_____     ");

                }

                else if(count == 3)
                {
                    System.out.println("  ------  ");
                    System.out.println("  |    0  ");
                    System.out.println("  |    |  ");
                    System.out.println("  |   / \\ ");
                    System.out.println("_____     ");

                }

                else if(count == 4)
                {
                    System.out.println("  ------  ");
                    System.out.println("  |    0  ");
                    System.out.println("  |   -|- ");
                    System.out.println("  |   / \\ ");
                    System.out.println("_____     ");
                }

                else if(count == 5)
                {
                    System.out.println("  ------ ");
                    System.out.println("       |    ");
                    System.out.println("  |    0  ");
                    System.out.println("  |   -|- ");
                    System.out.println("  |   / \\ ");
                    System.out.println("_____     ");
                }

                else if(count == 6)
                {
                    System.out.println("  YOU LOOSE! ");
                    System.out.println("  YOUR DEAD! ");
                    System.out.println("  ------ ");
                    System.out.println("       |    ");
                    System.out.println("  |    0  ");
                    System.out.println("  |   -|- ");
                    System.out.println("  |   / \\ ");
                    System.out.println("_____     ");
                    System.out.println("The phrase was: " + phrase);
                }
            }
            System.out.print(answer);
        }

    }


    public static boolean underscoreCheck(char[] u)
    {
        for(char c: u)
        {
            if( c == '_')
                return true;
        }
        return false;
    }
}
